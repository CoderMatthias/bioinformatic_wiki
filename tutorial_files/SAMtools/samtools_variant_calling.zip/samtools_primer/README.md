# SAMtools:  A Primer

Companion site for my tutorial:  [SAMTools:  A Primer](http://biobits.org/samtools_primer.html).